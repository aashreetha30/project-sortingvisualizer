<hr>

# Sorting Visualizer

<hr>

![](./Resources/mergeSort.gif)  

<hr>

 - ## Visualize the following Sorting Algorithms in one of the most efficient way
   - ### Bubble Sort 
   - ### Insertion Sort
   - ### Selection Sort
   - ### Heap Sort
   - ### Merge Sort
   - ### Quick Sort
 

  
- ## [Demo Link](https://rgtechno.github.io/Sorting_Visualizer/) 

<hr>

# Credits 
- ### [Dhruv Pasricha](https://github.com/DhruvPasricha)
- ### [Rahul Gandhi](https://github.com/RGTechno)

<hr>
